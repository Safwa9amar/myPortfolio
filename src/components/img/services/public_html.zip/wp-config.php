<?php
define( 'WP_CACHE', true );


//Begin Really Simple SSL session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple SSL

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u658324979_2cx9r' );

/** MySQL database username */
define( 'DB_USER', 'u658324979_0N9CC' );

/** MySQL database password */
define( 'DB_PASSWORD', 'dtY8ozeSUc' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '=BbuP,/M*OP93_al]lr}60ajqwC$,aIv3_(%)8?n8mRREa4o9sy_csou-P]jP4qQ' );
define( 'SECURE_AUTH_KEY',   'v!foK<.t@tvZY:S4r:-m~|o$]tJ{SCQ.fa/>U(;&`;SX|VL{uO;`l5(])45xG^-0' );
define( 'LOGGED_IN_KEY',     '6g4=8}sNM+L$GcEe=B_N*4`_1H}dJZl8O*+/qv^~PZSxvFKJwY|B( 0nyG#{dl@9' );
define( 'NONCE_KEY',         '!JK|_QIQ9=MA`8G);Se!kf#j)yqX(r?N)<7br^=6W)_ck]6f~FRLOP|;^,q;Yyji' );
define( 'AUTH_SALT',         'Q)Vda]+Kj_P2,_#XsQ[^4puUnU$H,aXBT;4.&M{rz5J>EN{KR0$9YWUj1Jf=Y~FZ' );
define( 'SECURE_AUTH_SALT',  '@l&eqwT[(`:i>,LHU=?h*+zjHC*ElPLLT)C%4_*7o+w_!>(tD8X-e&vLHwa9$=|O' );
define( 'LOGGED_IN_SALT',    'smeN(Q$t45XJIBR-Lb5D#2|Jf[6.;)^L4{U!Iy[OYy;N^Fi$,c7FimSr*HV*Kb*X' );
define( 'NONCE_SALT',        'YKS;*VJ^{Rf.I=^jj^5lC}nQ*+Iqv3N$Jr%l;x}cB%{c;WUa{5GbnvF7}/0|.}t5' );
define( 'WP_CACHE_KEY_SALT', 'v:=D}LrWvPbed.6d}f-j|=qOQXe@bH+jh##y+5~)c1!:Ph&O2@;k)=DFt6$a99F/' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
